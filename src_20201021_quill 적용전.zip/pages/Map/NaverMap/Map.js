import React from 'react';
import MapContainer from 'pages/Map/NaverMap/MapContainer';

const Map = () => {
    return (
        <MapContainer/>
    );
};

export default Map;