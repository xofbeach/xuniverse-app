export { default as Map } from './Map/NaverMap/Map';
export { default as Community } from './Community/Board/Community';