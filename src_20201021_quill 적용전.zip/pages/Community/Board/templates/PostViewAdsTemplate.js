import React from 'react';

class PostViewAdsTemplate extends React.Component {


    render() {
      return (
        <div>PostViewAdsTemplate</div>
      )
    }
  }

  export default PostViewAdsTemplate;