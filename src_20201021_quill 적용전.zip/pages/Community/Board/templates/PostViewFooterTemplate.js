import React from 'react';

class PostViewFooterTemplate extends React.Component {


    render() {
      return (
        <div>PostViewFooterTemplate</div>
      )
    }
  }

  export default PostViewFooterTemplate;