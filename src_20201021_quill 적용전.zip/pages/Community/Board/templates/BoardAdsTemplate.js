import React from 'react';

class BoardAdsTemplate extends React.Component {


    render() {
      return (
        <div>BoardAdsTemplate</div>
      )
    }
  }

  export default BoardAdsTemplate;