import React from 'react';

class BoardSearchOptionTemplate extends React.Component {

  render() {
    return (
      <div>BoardSearchOptionTemplate</div>
    )
  }

}

export default BoardSearchOptionTemplate;