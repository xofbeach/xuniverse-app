import React from 'react';
import XuniverseCommunity from 'components/community/XuniverseCommunity';
import queryString from 'query-string';

const Community = ({location, match, history}) => {
    const query = queryString.parse(location.search);
    const postId = query.postId;
    const curPage = query.curPage === undefined ? 1 : query.curPage;

    return (
      <div>
        <XuniverseCommunity
            history={history}
            postId={postId}
            curPage={curPage}
        />
      </div>
    );
};

export default Community;