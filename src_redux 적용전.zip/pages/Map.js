import React from 'react';
import Xuniverse from '../components/Xuniverse';

const Map = () => {
    return (
        <Xuniverse/>
    );
};

export default Map;