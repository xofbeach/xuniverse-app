import React, { Fragment } from 'react';
import axios from "axios";
import { RenderAfterNavermapsLoaded, NaverMap, Marker } from 'react-naver-maps';

// lib
import * as mapUtil from 'utils/mapUtil.js';
import * as convUtil from 'utils/convUtil.js';

// components
import MarkerImpl from 'components/MarkerImpl';
import RenderAfterNavermapsLoadedImpl from 'components/RenderAfterNavermapsLoadedImpl';
import ControlPanel from 'components/ControlPanel';
import SideInfomation from 'components/SideInfomation';
import SearchOptionGroup from 'components/SearchOptionGroup';

class Xuniverse extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        // RenderAfterNavermapsLoadedImpl
        center: { 
          // 그린팩토리 lat: 37.3595704, lng: 127.105399 
          lat: 37.4872035, // 타워팰리스
          lng: 127.0530399
        },
        zoom: 16,
        // FilterableProductTable
        filterText: '',
        inStockOnly: false,
        data : {},
        markers: [],
        refMap: false,
        sideInfomation : {
          visible: false,
          header : '',
          data : []
        },
        /**
         * searchOptionGroup
         * 검색어
         * 선택버튼
         */
        searchOptions: {
          searchKeyword : "",
          options: [
            {
              key : "trade",
              name : "매매",
              value: "0",
              selected: true,
              isShowDtl: false
          },
          {
              key : "type",
              name : "유형",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "area",
              name : "평형",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "price",
              name : "가격",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "household",
              name : "세대수",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "since",
              name : "입주년차",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "floorAreaRatio",
              name : "용적률",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "buildingCoverageRatio",
              name : "건폐율",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "rentRate",
              name : "전세가율",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "gapPrice",
              name : "갭가격",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "rentalBusinessRatio",
              name : "임대사업율",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "profitRatio",
              name : "월세수익율",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "parking",
              name : "주차공간",
              value: null,
              selected: false,
              isShowDtl: false
          },
          {
              key : "etc",
              name : "현관/난방",
              value: null,
              selected: false,
              isShowDtl: false
          },
        ]
        },
        login : {
          userId : null,
          isLogin: false,
          vendor : null,
          account : null
        }
      }
      // FilterableProductTable
      this.handleFilterTextChange = this.handleFilterTextChange.bind(this);
      this.handleInStockChange = this.handleInStockChange.bind(this);
      this.handlePanToTarget = this.handlePanToTarget.bind(this);
    }

    handleCenterChanged(center) {
      this.setState(center)
    }
  
    handleZoomChanged(zoom) {
      if (mapUtil.checkZoomChanged(zoom, this.state.zoom) || (Array.isArray(this.state.markers) && this.state.markers.length === 0)) {
        axios.post('http://localhost:8080/api/map/getMarkerPoint', {zoom:zoom})
        .then((response) => {
          const markers = [];
          const navermaps = window.naver.maps;
          const bounds = this.state.bounds;

          /**
           * { apt } 아파트
           * { rowHouse } 연립/다세대
           * { detachedHouse } 단독/다가구
           * { officetel } 오피스텔
           */
          const displayTrade = this.state.searchOptions.options[0].value === '0' || this.state.searchOptions.options[0].value === null ? 'trade' : 'rental'; // 0 : trade, 1 : rental
          const displayType = 'apt';
          const displayData = response.data[displayTrade][displayType];
          displayData.forEach((markerData) => {
            if (bounds.hasLatLng([markerData.x, markerData.y])) {
              markers.push(
                <MarkerImpl
                  markerData={markerData}
                  onMarkerClicked={(markerData) => this.handleMarkerClicked(markerData)}
                  zoom={zoom}
                  displayTrade={displayTrade}
                />
              );
            }
          });
  
          this.setState({
            markers : markers,
            zoom : zoom,
            data : response.data
          })
        });
      } else {
        this.setState({
          zoom : zoom
        })
      }
    }
  
    /**
     * Marker 클릭 시 클릭된 Marker의 lat, lng 값을 Center로 설정하고 Zoom 레벨 변경 시 데이터 조회
     * @param {*} data 
     */
    handleMarkerClicked(data) {
      let newZoom;
      if (this.state.zoom <= 10) {
        newZoom = 11;
        
      } else if (this.state.zoom >= 11 && this.state.zoom <= 12) {
        newZoom = 13;
      } else if (this.state.zoom >= 13 && this.state.zoom <= 15) {
        newZoom = 16;
      } else if (this.state.zoom >= 16) {
        newZoom = this.state.zoom;
      }
  
      if (newZoom >= 16 && this.state.zoom >= 16) {
        // sideInfomation 표시
        this.setState({
          sideInfomation : {
            ...this.state.sideInfomation,
            visible : true,
            header : data
          }
        })
        // 최대 Zoom 상태일 경우 해당 Marker 상세정보 조회
        this.getTargetDetail(data);
      } else {
        // 변경될 줌레벨로 조회
        this.handleZoomChanged(newZoom);
      }
      
      this.setState({
        zoom: newZoom,
        center: { lat: data.y, lng: data.x }
      })
    }
  
    getTargetDetail(data) {
      axios.post('http://localhost:8080/api/map/getTargetDetail', 
        {
          administrativeDistrictLev1:data.administrativeDistrictLev1,
          administrativeDistrictLev2:data.administrativeDistrictLev2,
          administrativeDistrictLev3:data.administrativeDistrictLev3,
          roadName:data.roadName,
          complexName:data.complexName
        }
      )
      .then((response) => {
        this.setState({
          sideInfomation : {
            ...this.state.sideInfomation,
            data : response.data
          }
        })
      });  
    }
  
    // FilterableProductTable
    handleFilterTextChange(filterText) {
      this.setState({
        filterText: filterText
      });
    }
    
    handleInStockChange(inStockOnly) {
      this.setState({
        inStockOnly: inStockOnly
      })
    }
  
    handlePanToTarget(x, y) {
      // axios.post('http://localhost:8080/api/map/getGeocode', {transactionId : transactionId})
      //   .then((response) => {
      //     // this.setState({
      //     //   products: response.data
      //     // })
      //     const geocode = response.data;
      //     // {X: "127.0571397", Y: "37.4763388"}
      //     this.setState({ center: { lat: geocode.Y, lng: geocode.X }})
      //     // this.setState({ center: { lat: 37.3595704, lng: 127.105399 }})
      //   });
  
        this.setState({ center: { lat: y, lng: x }})
    }
  
    componentDidMount() {
      // axios (
      //   {
      //       url: '/api/map/getAptRealTransactionDetail',
      //       method: 'post',
  
      //       /**
      //        * 개발 환경에서의 크로스 도메인 이슈를 해결하기 위한 코드로
      //        * 운영 환경에 배포할 경우에는 15~16행을 주석 처리합니다.
      //        * 
      //        * ※크로스 도메인 이슈: 브라우저에서 다른 도메인으로 URL 요청을 하는 경우 나타나는 보안문제
      //        */
      //       baseURL: 'http://localhost:8080',
      //       withCredentials: true,
      //   }
      // ).then((response) => {
      //     this.setState({ 
      //       products: response.data
      //     });
      // });
  
      // axios.post('http://localhost:8080/api/map/getAptRealTransData', {dealYear:"2020",dealMonth: "6", dealDay:"10"})
      //   .then((response) => {
      //     const markers = [];
      //     const navermaps = window.naver.maps;
      //     response.data.forEach((product) => {
      //       markers.push(
      //         <Marker
      //           key={product.transactionId}
      //           position={new navermaps.LatLng(product.y, product.x)}
      //           animation={0}
      //           onClick={() => {alert('naver green factofy');}}
      //           draggable={true}
      //           // icon={product.transactionId}
      //           icon={{                
      //             content:  [
      //               '<div class="cs_mapbridge">',
      //                 '<div class="map_group _map_group crs">',
      //                     '<div class="map_marker _marker num1 num1_big"> ',
      //                         '<span class="ico _icon">'+product.administrativeDistrictLev3+" "+product.complexName+'</span>',
      //                         '<span class="shd"></span>',
      //                     '</div>',
      //                 '</div>',
      //               '</div>'
      //             ].join(''),
      //             size:{width:32,height:32},
      //             scaledSize:{width:24,height:32},
      //             anchor: {x:12, y:32}
      //           }}
      //         />
      //       );
      //     });
      //     this.setState({
      //       products: response.data,
      //       markers : markers
      //     })
      //   });
  
      this.handleZoomChanged(this.state.zoom);
      window.Kakao.init('52246b2b953e7e32a35b038bdd0a908e');
    }
  
    handleBoundsChanged(bounds) {
      const markers = [];
      const navermaps = window.naver.maps;
      const zoom = this.state.zoom;
      const displayTrade = this.state.searchOptions.options[0].value === '0' || this.state.searchOptions.options[0].value === null ? 'trade' : 'rental'; // 0 : trade, 1 : rental
      const displayType = 'apt';
      const displayData = this.state.data[displayTrade][displayType];
      displayData.forEach((markerData) => {
        if (bounds.hasLatLng([markerData.x, markerData.y]))  {
          markers.push(
            <MarkerImpl
              markerData={markerData}
              onMarkerClicked={(markerData) => this.handleMarkerClicked(markerData)}
              zoom={zoom}
              displayTrade={displayTrade}
            />
          );
        }
      });
  
      this.setState({
        markers : markers
      })
    }
  
    mapRef(ref) {
      if (!this.state.refMap) {
        this.setState(state => ({
          refMap: true,
          bounds: ref.map.getBounds()
        }))
      }
    }
    
    handleCloseSideInfomation() {
      this.setState({
        sideInfomation : {
          ...this.state.sideInfomation,
          visible : false
        }
      })
    }

    handleShowSearchOptionDtl(key) {
      /**
       * 0) 기본사항
       *  0-1) 기본선택 ( 옵션 : 매매/ 디테일 : 매매/ 그외 옵션 : 전체 )
       * 
       * 1) 옵션 클릭
       *  1-1) 선택 된 옵션 클릭
       *    1-1-1) 디테일 뷰 활성화 / 선택된 디테일 표시
       *  1-2) 선택되지 않은 옵션 클릭
       *    1-2-1) 디테일 뷰 활성화 / 선택된 디테일이 없으므로 전체 표시
       *  1-3) 선택 된 옵션의 디테일 뷰가 활성화 되어 있는 경우 디테일 뷰 닫기
       * 
       * 2) 디테일 클릭
       *  2-1) 클릭 된 디테일 강조표시 / 옵션명을 디테일명으로 변경
       */
      const options = this.state.searchOptions.options;
      let newOptions = [];
    
      options.forEach(element => {
        let newOption;
        if (element.key === key) {
          newOption = {
            ...element,
            selected : element.value === null ? !element.selected : element.selected,
            isShowDtl : !element.isShowDtl
          }
        } else {
          newOption = {
            ...element,
            selected : element.value === null ? false : element.selected,
            isShowDtl : false
          }
        }
        newOptions.push(newOption);
      })
      this.setState({
        searchOptions :{
          options : newOptions
        }
      })
    }

    handleSelectSearchOption(dtlOptionKey, value) {
      let options = this.state.searchOptions.options;
      options.forEach(element => {
        if (element.key === dtlOptionKey) {
          if (dtlOptionKey === 'trade') {
            element.value = value;
          } else {

            element.value = value === "0" ? null : value;
          }
        }
      })
      this.setState({
        searchOptions : {
          options : options
        }
      })
      this.filterGroupChange();
    }

    filterGroupChange() {
      const markers = [];
      const bounds = this.state.bounds;
      const zoom = this.state.zoom;
      const displayTrade = this.state.searchOptions.options[0].value === '0' || this.state.searchOptions.options[0].value === null ? 'trade' : 'rental'; // 0 : trade, 1 : rental
      const displayType = 'apt';
      const displayData = this.state.data[displayTrade][displayType];
      displayData.forEach((markerData) => {
        if (bounds.hasLatLng([markerData.x, markerData.y])) {
          markers.push(
            <MarkerImpl
              markerData={markerData}
              onMarkerClicked={(markerData) => this.handleMarkerClicked(markerData)}
              zoom={zoom}
              displayTrade={displayTrade}
            />
          );
        }
      });

      let center = this.state.center;
      this.setState({
        markers : markers
      })
    }

    handleKakaoLoginClick() {
      const Kakao = window.Kakao;
      const _this = this;
      // login
      Kakao.Auth.login({
        success: function(response) {
          // request account
          Kakao.API.request({
            url: '/v2/user/me',
            success: function(response) {
              // setState
              _this.setLogin('kakao', response);
              _this.checkLoginUser();
            },
            fail: function(error) {
              console.log(error);
            }
          });
        },
        fail: function(error) {
          console.log(error);
        },
      });
    }

    setLogin(vendorName, userAccount) {
      this.setState({
        login : {
          ...this.state.login,
          isLogin : true,
          vendor : vendorName,
          account : userAccount
        }
      });
    }

    handleKaKaoLogoutClick() {
      const Kakao = window.Kakao;
      if (Kakao.Auth.getAccessToken()) {
        console.log('카카오 인증 액세스 토큰이 존재합니다.', Kakao.Auth.getAccessToken())
        Kakao.Auth.logout(() => {
          console.log('로그아웃 되었습니다', Kakao.Auth.getAccessToken());
          // this.setState({
          //   isLogin: false
          // })        
        });
      }
    }

    checkLoginUser() {
      const loginUser = this.state.login;
      axios.post('http://localhost:8080/api/user/checkLoginUser',
        {
          vendor : loginUser.vendor,
          externalId : loginUser.account.id,
          connected_at : loginUser.account.connected_at,
          nickname : loginUser.account.properties.nickname,
        }
      )
      .then((response) => {
        window.sessionStorage.setItem('userId', response.data.userId);
        this.setState({
          login : {
            ...this.state.login,
            userId : response.data.userId
          }
        })
      });
    }

    render() {
      return (
        <Fragment>
          <RenderAfterNavermapsLoaded ncpClientId='8yviwlp4q3'>
            <RenderAfterNavermapsLoadedImpl 
              center={this.state.center}
              zoom={this.state.zoom}
              markers={this.state.markers}
              onCenterChanged={(center) => this.handleCenterChanged(center)}
              onZoomChanged={(zoom) => this.handleZoomChanged(zoom)}
              onBoundsChanged={(bounds) => this.handleBoundsChanged(bounds)}
              mapRef={(ref) => this.mapRef(ref)}
            />
          </RenderAfterNavermapsLoaded>
          {/* <FilterableProductTable
            filterText={this.state.filterText}
            inStockOnly={this.state.inStockOnly}
            products={this.state.products}
            handleFilterTextChange={(t) => this.handleFilterTextChange(t)}
            handleInStockChange={(t) => this.handleInStockChange(t)}
            handlePanToTarget={(x, y) => this.handlePanToTarget(x, y)}
          /> */}
          <SearchOptionGroup
            onShowSearchOptionDtl={(key) => this.handleShowSearchOptionDtl(key)}
            onSelectSearchOption={(dtlOptionKey, value) => this.handleSelectSearchOption(dtlOptionKey, value)}
            onSearchOptionSelect
            searchOptions={this.state.searchOptions}
          />
          <SideInfomation
            sideInfomationData={this.state.sideInfomation.data}
            aptTransDataHeader={this.state.sideInfomation.header}
            visible={this.state.sideInfomation.visible}
            onCloseSideInfomation={() => this.handleCloseSideInfomation()}
          />
          <ControlPanel
            onKakaoLoginClick={() => this.handleKakaoLoginClick()}
            onKakaoLogoutClick={() => this.handleKaKaoLogoutClick()}
            onKakaoAccountRequestClick={() => this.handleKakaoAccountRequestClick()}
          />
        </Fragment>
      )
    }
  }

  export default Xuniverse;