import React, { Fragment } from 'react';

import SearchBar from 'components/SearchBar';
import ProductTable from 'components/ProductTable';

class FilterableProductTable extends React.Component {
    render() {
      return (
        <div>
          <SearchBar
            filterText={this.props.filterText}
            inStockOnly={this.props.inStockOnly}
            onFilterTextChange={(t) => this.props.handleFilterTextChange(t)}
            onInStockChange={(t) => this.props.handleInStockChange(t)}
          />
          <ProductTable
            products={this.props.products}
            filterText={this.props.filterText}
            inStockOnly={this.props.inStockOnly}
            handlePanToTarget={(x, y) => this.props.handlePanToTarget(x, y)}
          />
        </div>
      );
    }
  }

  export default FilterableProductTable;