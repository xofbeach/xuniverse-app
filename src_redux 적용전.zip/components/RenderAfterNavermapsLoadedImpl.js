import React, { Fragment } from 'react';
import { RenderAfterNavermapsLoaded, NaverMap, Marker } from 'react-naver-maps';

class RenderAfterNavermapsLoadedImpl extends React.Component {
    componentDidMount() {
      // this.setState({ initBounds: this.naverMapRef.instance.getBounds() })   
    }
  
    render() {
      return (
        <div>
          <NaverMap 
            naverRef={(ref) => this.props.mapRef(ref) }
            id='maps-getting-started-controlled' 
            style={{width: '100%', height: '800px'}}
            
            // uncontrolled zoom
            defaultZoom={this.props.zoom}
  
            // controlled center
            // Not defaultCenter={this.state.center}
            center={this.props.center}
            zoom={this.props.zoom}
            onCenterChanged={center => this.props.onCenterChanged({center})}
            onZoomChanged={(zoom)=> this.props.onZoomChanged(zoom)}
            onBoundsChanged={(bounds) => this.props.onBoundsChanged(bounds)}
          >
            {this.props.markers}
          </NaverMap>
          <p style={{textAlign: "right"}}>lat: {this.props.center.y || this.props.center.lat} / lng: {this.props.center.x || this.props.center.lng} / zoom: {this.props.zoom}</p>
        </div>
      )
    }
}

export default RenderAfterNavermapsLoadedImpl;