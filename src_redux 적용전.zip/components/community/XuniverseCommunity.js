import React, { Fragment } from 'react';
import axios from "axios";
import { RenderAfterNavermapsLoaded, NaverMap, Marker } from 'react-naver-maps';

import BoardHeader from 'components/community/BoardHeader';
import BoardBody from 'components/community/BoardBody';
import BoardPaging from 'components/community/BoardPaging';
import BoardSearchOption from 'components/community/BoardSearchOption';
import BoardAds from 'components/community/BoardAds';

import PostViewHeader from 'components/community/PostViewHeader';
import PostViewBody from 'components/community/PostViewBody';
import PostViewReply from 'components/community/PostViewReply';
import PostViewWriteReply from 'components/community/PostViewWriteReply';
// import PostViewFooter from 'components/community/PostViewFooter';
// import PostViewAds from 'components/community/PostViewAds';

import PostWriteHeader from 'components/community/PostWriteHeader';
import PostWriteBody from 'components/community/PostWriteBody';

class XuniverseCommunity extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        category : '',
        /**
         * BoardBody : 게시글 목록
         */
        postList : {
          data : [],
          count : '',
        },
        /**
         * PostViewBody : 게시글(1건)
         */
        post : {
          data : {}
        },
        /**
         * PostViewReply : 댓글 목록
         */
        replyList : {
          data : []
        },
        /**
         * PostViewReply : 댓글
         */
        reply : {
          data : null,
        },
        /**
         * PostViewReply : 대댓글 또는 댓글 수정
         */
        reReply : {
          data : null,
        },
        /**
         * BoardPaging : 페이징
         */
        pagination : {
          curPage : this.props.curPage
        },


        writePost : {
          title : null,
          content : null
        },
        login : {
          userId : null,
          isLogin: false,
          vendor : null,
          account : null
        }
      }
    }

    componentDidMount() {
      this.props.postId === undefined 
        ? this.getPostList() 
        : this.getPostById();

      this.getAccount();
    }

    getAccount() {
      const Kakao = window.Kakao;
      const _this = this;
      // request account
      Kakao.API.request({
        url: '/v2/user/me',
        success: function(response) {
          // setState
          _this.setLogin('kakao', response);
          _this.checkLoginUser();
        },
        fail: function(error) {
          console.log(error);
        }
      });
    }

    setLogin(vendorName, userAccount) {
      this.setState({
        login : {
          ...this.state.login,
          isLogin : true,
          vendor : vendorName,
          account : userAccount
        }
      });
    }

    checkLoginUser() {
      const loginUser = this.state.login;
      axios.post('http://localhost:8080/api/user/checkLoginUser',
        {
          vendor : loginUser.vendor,
          externalId : loginUser.account.id,
          connected_at : loginUser.account.connected_at,
          nickname : loginUser.account.properties.nickname,
        }
      )
      .then((response) => {
        window.sessionStorage.setItem('userId', response.data.userId);
        this.setState({
          login : {
            ...this.state.login,
            userId : response.data.userId
          }
        })
      });
    }

    getPostList() {
      axios.post('http://localhost:8080/api/community/getPostList', {curPage:this.state.pagination.curPage})
      .then((response) => {
        const postList = response.data.postList;
        const postCount = response.data.postCount;
        const pagination = response.data.pagination;
        
        this.setState({
          postList : {
            data : postList,
            count : postCount
          },
          pagination : pagination
        })
      });
    }

    getPostById() {
      axios.post('http://localhost:8080/api/community/getPostById', {postId:this.props.postId})
      .then((response) => {
        const post = response.data.post;
        const replyList = response.data.replyList;
        this.setState({
          post : {
            data : post
          },
          replyList : {
            data : replyList
          }
        })
      });
    }

    handlePageNumberClick(pageNumber) {
      this.setState({
        pagination : {
          ...this.state.pagination,
          curPage : pageNumber
        }
      }, () => {
        this.getPostList();
      })
    }

    handlePostModifyClick(postId) {
      
    }

    handlePostDeleteClick(postId) {
      axios.post('http://localhost:8080/api/community/deletePostById', {postId:this.props.postId})
      .then((response) => {
        this.props.history.push('/board/postList');
      });
    }

    handlePostListClick(curPage) {
      this.props.history.push('/board/postList?curPage='+curPage);
    }

    handleReplyChange(reply) {
      this.setState({
        reply : {
          data : reply
        }
      })
    }

    handleReplyRegister() {
      // const data = {postId : this.props.postId,reply : this.state.reply.data}
      axios.post('http://localhost:8080/api/community/registerReply', {
        postId : this.props.postId, 
        reply : this.state.reply.data,
        userId : this.state.login.userId
      })
      .then((response) => {
        this.setState({
          reply : {
            data : null
          }
        })
        this.getPostById()
      });
    }

    handleReReplyWriteClick(bundleId) {
      let replyList = this.state.replyList.data;
      let spliceIndex;
      let postId;
      let upperReplyId;

      /**
       * 생성된 대댓글 입력창이 존재할 경우 제거
       */
      replyList.some((data, index) => {
        if (data.remark && data.remark === 'INSERT_HERE') {
          replyList.splice(index, 1);
          return true;
        }
      })
      /**
       * 답글쓰기 대상 다음에 대댓글 입력창 생성
       */
      replyList.forEach((data, index) => {
        if (data.bundleId === bundleId) {
          if (!data.upperReplyId) upperReplyId = data.replyId;
          spliceIndex = index+1;
        }
      });
      replyList.splice(spliceIndex, 0, {
        postId : this.props.postId,
        upperReplyId : upperReplyId,
        bundleId : bundleId, 
        remark : 'INSERT_HERE'
      });
      this.setState({
        replyList :{
          data : replyList
        }
      })
    }

    handleReReplyChange(reReply){
      this.setState({
        reReply : {
          data : reReply
        }
      })
    }

    handleReReplyWriteCancelClick() {
      let replyList = this.state.replyList.data;

      /**
       * 생성된 대댓글 입력창 또는 수정입력창이 존재할 경우 제거 또는 기존내용 표시
       */
      replyList.some((data, index) => {
        if (data.remark && data.remark === 'MODIFY_HERE') {
          /**
           * MODIFY_HERE
           * edit mode flag (MODIFY_HERE) 제거
           * 기존내용 재 렌더링
           */
          delete data.remark;
          return true;
        } else if (data.remark && data.remark === 'INSERT_HERE') {
          /**
           * INSERT_HERE
           * insert mode 제거
           * 재 렌더링시 해당 인덱스 내용 삭제
           */
          replyList.splice(index, 1);
          return true;
        }
      })
      this.setState({
        replyList :{
          data : replyList
        },
        reReply : {
          data : null
        }
      })
    }

    handleReReplyWriteRegisterClick(replyId, bundleId, upperReplyId) {
      if (replyId === undefined) {
        axios.post('http://localhost:8080/api/community/registerReReply',
          {
            postId : this.props.postId,
            bundleId : bundleId,
            upperReplyId : upperReplyId,
            reReply : this.state.reReply.data,
            userId : this.state.login.userId
          })
        .then((response) => {
          this.setState({
            reReply : {
              data : null
            }
          })
          this.getPostById()
        });
      } else {
        this.reReplyModify(replyId);
      }
    }

    handleReReplyModifyClick(replyId) {
      let replyList = this.state.replyList.data;
      let spliceIndex;
      let targetOriginalData;

      /**
       * 생성된 수정입력창이 존재할 경우 제거
       */
      replyList.some((data, index) => {
        if (data.remark && data.remark === 'MODIFY_HERE') {
          replyList.splice(index, 1);
          return true;
        }
      })
      /**
       * 타겟에 수정입력창 입력창 생성
       */
      replyList.forEach((data, index) => {
        if (data.replyId === replyId) {
          spliceIndex = index;
          targetOriginalData = data;
        }
      });
      replyList.splice(spliceIndex, 1, {
        ...targetOriginalData,
        remark : 'MODIFY_HERE'
      });
      this.setState({
        replyList :{
          data : replyList
        },
        reReply : {
          data : targetOriginalData.content
        }
      })
    }

    reReplyModify(replyId) {
      axios.post('http://localhost:8080/api/community/modifyReReply',
        {
          replyId : replyId,
          reReply : this.state.reReply.data
        })
      .then((response) => {
        this.setState({
          reReply : {
            data : null
          }
        })
        this.getPostById()
      });
    }

    handleReReplyDeleteClick(replyId) {
      axios.post('http://localhost:8080/api/community/deleteReReply',
        {
          replyId : replyId
        })
      .then((response) => {
        this.getPostById()
      });
    }

    handlePostWriteClick() {
      this.props.history.push('/board/postWrite');
    }

    handlePostWriteContentChange(content) {
      this.setState({
        writePost : {
          ...this.state.writePost,
          content : content
        }
      })
    }
    
    handlePostWriteTitleChange(title) {
      this.setState({
        writePost : {
          ...this.state.writePost,
          title : title
        }
      })
    }

    handlePostWriteRegisterClick() {
      console.log(this.state.writePost.title)
      console.log(this.state.writePost.content)
      axios.post('http://localhost:8080/api/community/registerPostWrite',
        {
          title : this.state.writePost.title,
          content : this.state.writePost.content,
          userId : this.state.login.userId,
        })
      .then((response) => {
        this.props.history.push('/board/postList');
      });
    }



    render() {
      const postId = this.props.postId;
      const curPage = this.state.pagination.curPage;
      const pathname = this.props.history.location.pathname;

      /**
       * pathname :
       * 게시글 목록 /board/postList
       * 게시글 보기 /board/postView
       * 게시글 쓰기 /board/postWrite
       * 게시글 수정 /board/postModify
       */
      // if (postId === undefined) {
      if (pathname === '/board/postList') {
        return (
          <Fragment>
            <BoardHeader/>
            <BoardBody
              curPage={curPage}
              postList={this.state.postList}
              onPostWriteClick={() => this.handlePostWriteClick()}
            />
            <BoardPaging
              pagination={this.state.pagination}
              onPageNumberClick={(pageNumber) => this.handlePageNumberClick(pageNumber)}
            />
            <BoardSearchOption/>
            <BoardAds/>
          </Fragment>
        )
      } else if (pathname === '/board/postView') {
        return (
          <Fragment>
            <PostViewHeader
              postId={postId}
              curPage={curPage}
              onPostModifyClick={(postId) => this.handlePostModifyClick(postId)}
              onPostDeleteClick={(postId) => this.handlePostDeleteClick(postId)}
              onPostListClick={(curPage) => this.handlePostListClick(curPage)}
            />
            <PostViewBody
              postId={postId}
              postData={this.state.post.data}
            />
            <PostViewReply
              replyList={this.state.replyList.data}
              onReReplyWriteClick={(bundleId) => this.handleReReplyWriteClick(bundleId)}
              
              reReply={this.state.reReply.data}
              onReReplyChange={(reReply) => this.handleReReplyChange(reReply)}
              onReReplyWriteCancelClick={() => this.handleReReplyWriteCancelClick()}
              onReReplyWriteRegisterClick={(replyId, bundleId, upperReplyId) => this.handleReReplyWriteRegisterClick(replyId, bundleId, upperReplyId)}
              onReReplyModifyClick={(replyId) => this.handleReReplyModifyClick(replyId)}
              onReReplyDeleteClick={(replyId) => this.handleReReplyDeleteClick(replyId)}
            />
            <PostViewWriteReply
              reply={this.state.reply.data}
              onReplyChange={(reply) => this.handleReplyChange(reply)}
              onReplyRegister={() => this.handleReplyRegister()}
            />
            {/* <PostViewFooter/> */}
            {/* <PostViewAds/> */}
          </Fragment>
        )
      } else if (pathname === '/board/postWrite') {
        return (
          <Fragment>
            <PostWriteHeader
              onPostWriteRegisterClick={() => this.handlePostWriteRegisterClick()}
            />
            <PostWriteBody
              onPostWriteTitleChange={(title) => this.handlePostWriteTitleChange(title)}
              onPostWriteContentChange={(content) => this.handlePostWriteContentChange(content)}
            />
          </Fragment>
        )
      }
    }
  }

  export default XuniverseCommunity;