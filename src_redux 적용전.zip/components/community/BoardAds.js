import React from 'react';

class BoardAds extends React.Component {


    render() {
      return (
        <div>BoardAds</div>
      )
    }
  }

  export default BoardAds;