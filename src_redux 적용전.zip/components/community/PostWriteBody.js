import React from 'react';
import { Link } from 'react-router-dom';
import axios from "axios";

import 'codemirror/lib/codemirror.css';
import '@toast-ui/editor/dist/toastui-editor.css';

import { Editor, Viewer } from '@toast-ui/react-editor';
import { htmlImage } from 'utils/dataUtil.js';

class PostViewBody extends React.Component {
    editorRef = React.createRef();

  // handleFocus = () => {
  //   console.log('focus!!');
  // };

  handleClickGetHtmlButton = () => {
    console.log(this.editorRef.current.getInstance().getHtml())
  }
  render() {
    return (
      <div>
        <table>
          <tr>
            <input
              onChange={(e) => this.props.onPostWriteTitleChange(e.target.value)}
            />
          </tr>
        </table>
        <hr/>
        <Editor
          // initialValue='hello'
          // previewStyle="vertical"
          height="600px"
          initialEditType="wysiwyg"
          useCommandShortcut={true}
          ref={this.editorRef}
          // onFocus={this.handleFocus}
          onChange={() => this.props.onPostWriteContentChange(this.editorRef.current.getInstance().getHtml())}
        />
        {/* <button onClick={this.handleClick}>make bold</button> */}
        {/* <button onClick={this.handleClickGetHtmlButton}>get HTML</button> */}
        <hr/>
      </div>
    )
  }
}

export default PostViewBody;