import React from 'react';

class BoardPaging extends React.Component {
  render() {
    const pages = [];
    const pagination = this.props.pagination;
    const startPage = pagination.startPage;
    const endPage = pagination.endPage;
    const curPage = pagination.curPage;
    const pageCnt = pagination.pageCnt;
    const prevPage = pagination.prevPage;

    // prev
    if (prevPage !== 0 && prevPage !== undefined) {
      pages.push(
        <button onClick={() => this.props.onPageNumberClick(pagination.prevPage)}>←이전</button>
      )
    }
    // pageNumber
    for (let pageNumber=startPage; pageNumber<=endPage; pageNumber++) {
      pages.push(
        pageNumber === curPage 
          ? <button onClick={() => this.props.onPageNumberClick(pageNumber)}><strong>{pageNumber}</strong></button> 
          : <button onClick={() => this.props.onPageNumberClick(pageNumber)}>{pageNumber}</button>
      );
    }
    // next
    if (pageCnt > endPage) {
      pages.push(
        <button onClick={() => this.props.onPageNumberClick(pagination.nextPage)}>다음→</button>
      )
    }
    return (
      <div>
        {pages}
      </div>
    )
  }
}

export default BoardPaging;