import React from 'react';

class PostViewHeader extends React.Component {
  render() {
    const postId = this.props.postId;
    const curPage = this.props.curPage;

    return (
      <div>
        <div>
          <button onClick={() => this.props.onPostModifyClick(postId)}>수정</button>
          <button onClick={() => this.props.onPostDeleteClick(postId)}>삭제</button>
        </div>
        <div>
          <button>이전글</button>
          <button>다음글</button>
          <button onClick={() => this.props.onPostListClick(curPage)}>목록</button>
        </div>
      </div>
    )
  }
}

export default PostViewHeader;