import React from 'react';

class PostViewReply extends React.Component {
  render() {
    const replyList = this.props.replyList;
    const rows = [];
    replyList.forEach(data => {
      const postId = data.postId;
      const upperReplyId = data.upperReplyId;
      const upperWriterNickname = data.upperWriterNickname;
      const bundleId = data.bundleId;
      const replyId = data.replyId;
      if (data.remark && (data.remark === 'INSERT_HERE' || data.remark === 'MODIFY_HERE')) {
        rows.push(
          <div style={{backgroundColor: 'lightgray'}}>
            <p>
              <textarea 
                value={this.props.reReply}
                onChange={(e) => this.props.onReReplyChange(e.target.value)}
              ></textarea>
            </p>
            <p>
              <button onClick={() => this.props.onReReplyWriteCancelClick()}>취소</button>
              <button onClick={() => this.props.onReReplyWriteRegisterClick(replyId, bundleId, upperReplyId)}>등록</button>
            </p>
            <hr/>
          </div>
        )
      } else {
        rows.push(
          <div>
            <p>{upperReplyId === undefined ? '': '　　　'}{data.nickname}</p>
            <p>{upperReplyId === undefined ? '': '　　　'}{upperWriterNickname === undefined ? '' : <strong>{upperWriterNickname} </strong>}{data.content}</p>
            <p>
              {upperReplyId === undefined ? '': '　　　'}{data.writeDate}　
              <button onClick={() => this.props.onReReplyModifyClick(replyId)}>수정</button>
              <button onClick={() => this.props.onReReplyDeleteClick(replyId)}>삭제</button>
              <button onClick={() => this.props.onReReplyWriteClick(bundleId)}>답글쓰기</button>
            </p>
            <hr/>
          </div>
        )
      }
    });
    return (
      <div>
        {rows}
      </div>
    )
  }
}

export default PostViewReply;