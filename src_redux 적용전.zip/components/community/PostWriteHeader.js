import React from 'react';

class PostViewHeader extends React.Component {
  render() {
    const postId = this.props.postId;
    const curPage = this.props.curPage;

    return (
      <div>
        <div>
          <button onClick={() => this.props.onPostWriteRegisterClick()}>등록</button>
        </div>
      </div>
    )
  }
}

export default PostViewHeader;