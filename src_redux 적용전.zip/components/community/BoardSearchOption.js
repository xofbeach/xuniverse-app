import React from 'react';

class BoardSearchOption extends React.Component {


    render() {
      return (
        <div>BoardSearchOption</div>
      )
    }
  }

  export default BoardSearchOption;