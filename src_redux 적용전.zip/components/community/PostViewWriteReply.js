import React from 'react';
import { Link } from 'react-router-dom';

class PostViewWriteReply extends React.Component {
  render() {
    return (
      <div>
        <fieldset>
          <legend>댓글을 남겨보세요.</legend>
          <input
            value={this.props.reply}
            onChange={(e) => this.props.onReplyChange(e.target.value)} />
          <button onClick={() => this.props.onReplyRegister()}>등록</button>
        </fieldset>
      </div>
    )
  }
}

export default PostViewWriteReply;