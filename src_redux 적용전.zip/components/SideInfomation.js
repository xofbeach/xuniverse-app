import React, { Fragment } from 'react';

import SideInfomationAptTransData from 'components/SideInfomationAptTransData';

class SideInfomation extends React.Component {
    render() {
      if (this.props.visible) {
        const rows = [];
        const aptTransDataHeader = this.props.aptTransDataHeader;
        const sideInfomationData = this.props.sideInfomationData;
        sideInfomationData.forEach((data) => {
          rows.push(
            <SideInfomationAptTransData
              data={data}
            />
          );
        });
        return (
          <div id="container">
            <div class="scene-poi">
              <div class="poi-detail">
                <a href="#" class="btn-close" data-ga-event="apt,closeBtn" onClick={() => this.props.onCloseSideInfomation()}><span>닫기</span></a>
                {/* <table> */}
                  <p>{aptTransDataHeader.complexName}</p>
                  <p>{aptTransDataHeader.administrativeDistrictLev1} {aptTransDataHeader.administrativeDistrictLev2} {aptTransDataHeader.administrativeDistrictLev3} {aptTransDataHeader.roadName}</p>
                {/* </table> */}
                <table>
                  <thead>
                    <tr>
                      <th>계약일자</th>
                      <th>거래금액(만원)</th>
                      <th>전용면적m²(평)</th>
                      <th>층</th>
                    </tr>
                  </thead>
                  <tbody>{rows}</tbody>
                </table>
              </div>
            </div>
          </div>
        )
      } else {
        return(null)
      }
    }
  }

export default SideInfomation;