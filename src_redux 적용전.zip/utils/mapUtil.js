/**
 * 변경 된 Zoom, 변경 전 Zoom을 입력받아 Zoom 변경 여부를 반환합니다.
 * @param {number} newZoom 변경 된 Zoom 레벨
 * @param {number} newZoom 변경 전 Zoom 레벨
 * @return {boolean} Zoom 변경 여부
 */
var checkZoomChanged = function(newZoom, origZoom) {
  // ~10      시도 1
  // 11~ 12   구 2
  // 13~ 15   동 3
  // 16~      개별 4
  let newZoomLev;
  let origZoomLev;
  let result = false;
  // newZoom
  if (newZoom >= 16) {
    newZoomLev = 4;
  } else if (newZoom >= 13 && newZoom <= 15) {
    newZoomLev = 3;
  } else if (newZoom >= 11 && newZoom <= 12) {
    newZoomLev = 2;
  } else if (newZoom <= 10) {
    newZoomLev = 1;
  }
  //origZoom
  if (origZoom >= 16) {
    origZoomLev = 4;
  } else if (origZoom >= 13 && origZoom <= 15) {
    origZoomLev = 3;
  } else if (origZoom >= 11 && origZoom <= 12) {
    origZoomLev = 2;
  } else if (origZoom <= 10) {
    origZoomLev = 1;
  }

  if (newZoomLev !== origZoomLev) {
    result = true;
  }
  return result;
}




exports.checkZoomChanged = checkZoomChanged;